#include<iostream>
#include<string>
#include<fstream>
#include<stdlib.h>
#include"class.h"
using namespace std;

//global variables

 long double  population = 0;
long double total_sinopharm=0;
long double total_pfizer=0;
const double sino_price = 120;
const double pfizer_price = 150;
expiry_date e_obj;
double Number_of_doses;
long double each_warehouse_vaccine = 0;
long double each_warehose_pfizer = 0;
long double each_warehouse_sinopharm = 0;


void allignment() {

	cout << "\t\t\t\t\t**********************************************************************\n";
	cout << "\t\t\t\t\t*                                                                    *\n";
	cout << "\t\t\t\t\t*                                                                    *\n";
	cout << "\t\t\t\t\t*                                                                    *\n";
	cout << "\t\t\t\t\t*                                                                    *\n";
	cout << "\t\t\t\t\t*                VACCINE MANAGEMENT SYSTEM                           *\n";
	cout << "\t\t\t\t\t*                                                                    *\n";
	cout << "\t\t\t\t\t*                                                                    *\n";
	cout << "\t\t\t\t\t*                                                                    *\n";
	cout << "\t\t\t\t\t*                                                                    *\n";
	cout << "\t\t\t\t\t**********************************************************************\n";
	cout << "\n\n\n";

}


int menu()                          //global function
{
	int count = 0;
	int menu_selection;
	cout << "\t\t\t\t\tChoose your role:\n";
	cout << "\t\t\t\t\t1. Super Admin\n";
	cout << "\t\t\t\t\t2. Admin\n";
	cout << "\t\t\t\t\t3. Doctor\n";
	cout << "\t\t\t\t\t4. FDO\n";
	cout << "\t\t\t\t\t5. Governament Official\n";
	cout << "\t\t\t\t\t6. Citizen\n";
	cout << "\t\t\t\t\tTo exit program enter 0\n";
	cout << "\t\t\t\t\tINPUT:  ";cin >> menu_selection;
	
	if( (menu_selection < 0 || menu_selection > 6) ||((menu_selection>='A')&&(menu_selection<='Z'))|| ((menu_selection >= 'a') && (menu_selection <= 'z'))) {
			cout << "\t\t\t\t\tInvalid input\n";
			cout << "\t\t\t\t\tEnter your selectin input again:    ";
			menu();
		}
		
		return menu_selection;
}

////////////////////PERSON CLASS/////////////////////////

//constructor
person::person()
{
	cout << endl;
	cout << "Enter username :   ";cin >> this->username;
	cout << "Enter password:   ";cin >> this->password;
	int len_password = password.length();
	while (len_password != 8)
	{
		cout << "your password must be of 8 lenghth" << endl;
		cout << "so,please again enter password" << endl;
		cin >> this->password;
		len_password = password.length();
	}
	cout << "in person constructor" << endl;
	string temp;
	cout << "Enter user-ID:   ";cin >> ID;
	int len_id = ID.length();
	while (len_id !=5)
	{
		cout << "your ID must be of 5 lenghth" << endl;
		cout << "so,please again enter ID" << endl;
		cin >> ID;
		len_id = ID.length();
	}
}

///////////////////////////getters
string person::get_username()
{
	return this->username;
}
string person::get_password()
{
	return password;
}
string person::get_ID()                       //we are using these getter beacuse in check login function when we class other_roles_files
{
	return ID;                                  //we are giving these username,password and ID parameter that's why....
}



////////////////////////VACCINE CLASS///////////////////////////


int vaccine::add_vaccine()
{
	fstream cities_name;
	cities_name.open("cities_name.txt");
	if (!cities_name)
	{
		cout << "Error in opening City name file\n";
		return -3;
	}
	else
	{
		cout << "Cities name file open successfully" << endl;
		cities_name << "Chiniot" << endl;
		cities_name << "Faislabad" << endl;
		cities_name << "Islamabad" << endl;
		cities_name << "Karachi" << endl;
		cities_name << "Lahore" << endl;
		cities_name << "Multan" << endl;
		cities_name << "Murree" << endl;
		cities_name << "Quetta" << endl;
		cities_name << "Gujrat" << endl;
	}

	cities_name.close();
	fstream vacc_file;
	vacc_file.open("City_data.txt");
	if (!vacc_file) {
		cout << "Error in opening City data file\n";
		return -3;
	}
	else {

		cout << "file open successfully" << endl;
		string sub;
		string Str;
		vacc_file << "2045" << endl;
		vacc_file << "3084" << endl;
		vacc_file << "3475" << endl;
		vacc_file << "4467" << endl;
		vacc_file << "3066" << endl;
		vacc_file << "2024" << endl;
		vacc_file << "2076" << endl;
		vacc_file << "4223" << endl;
		vacc_file << "2068" << endl;
		vacc_file << "2234" << endl;
		vacc_file.close();

		ifstream vacc_file;                                 //to read from file
		vacc_file.open("City_data.txt", ios::in);
		string pop;
		if (r_Number_of_doses < 50000)
		{
				while (getline(vacc_file, pop))                     //it's converting string into integer
				{
					if (pop == "")
					{
						continue;
					}
					population =population+ stoi(pop);
				}
				vacc_file.close();
			cout << endl;
			cout << "Admin please enter todays date: ";                     // now we have the total number of vaccine we are suppose to purchase
			cin>>e_obj.date;
			cout << "Admin please enter month: ";                    
			cin >> e_obj.month;
			cout << "Admin please enter year: ";                  
			cin >> e_obj.year;
			Number_of_doses = population;                             //total popoulation has been stored in this as we have to purchase this number of vaccine dozes
			total_sinopharm = Number_of_doses / 2;
			total_pfizer = Number_of_doses - total_sinopharm;
			Batch_ID++;
			return 0;
		}

		else
		{
			cout << "You have already enough doses of vaccine" << endl;
			cout << "Due to expiry date issue you cannot purchase vaccine for now" << endl;
			return 0;
		}

	}
	return 0;
}




bool other_roles_files(string x, string y, string z)
{
	 int count = 0;
	bool check = false;     //check variable check the login it is successfull or not it return true or false
	fstream other_roles;
	other_roles.open("other_roles.txt",ios::in|ios::out);
	if (!other_roles.is_open()) {
		cout << "OOPS! error in openning other roles file\n";
		return 1;
	}
	else {
		other_roles << "laiba,12345678:67890" << endl;
		other_roles << "momna,22334455:00768" << endl;
		other_roles << "hafsa,87876767:99880" << endl;
		other_roles << "kamla,11221122:55443" << endl;
		ifstream other_roles;
		string str;
		other_roles.open("other_roles.txt", ios::in);
		cout << "other role file openend succefully\n";
		while ((getline(other_roles, str, '\n'))&&(count<3))
		{
			int pos = str.find(",");
			int pos1 = str.find(":");
			string sub = str.substr(0, pos);
			cout << "\nsub is " << sub << endl;
			if (x == sub)
			{
				count++;
				sub = str.substr(pos + 1, 8);
				cout << "\nsub is " << sub << endl;
				if (sub == y)
				{
					count++;
					sub = str.substr(pos1 + 1, 5);
					cout << "\nsub is " << sub << endl;
					if (sub == z)
					{
						count++;
						check = true;
					}
					else
					{
						check = false;
					}

				}
				else
				{
					check = false;
				}
			}
			else
			{
				check = false;
			}
		}
	}
	//other_roles.close();
	return check;
}
void vaccine::store_in_warehouse()
{

	const int SIZE = 10;
	int i = 0;
	double ware_houses[SIZE] = { 0 };
	string sub;
	fstream vacc_file;                                 //to read from file
	vacc_file.open("City_data.txt", ios::in);

	r_Number_of_doses = Number_of_doses;
	r_total_pfizer = total_pfizer;
	r_total_sinopharm = total_sinopharm;
	while (getline(vacc_file, sub, '\n'))
	{
		if (sub == "")
		{
			continue;
		}
		double temp = stoi(sub);
		ware_houses[i] = temp;
		r_Number_of_doses = r_Number_of_doses - temp;
		r_total_pfizer = r_total_pfizer - (temp / 2);
		r_total_sinopharm = r_total_sinopharm - (temp / 2);
		i++;
	}
	vacc_file.close();
}
int* vaccine::vaccination_centres() {
	int i = 0;
	string sub;
	int centre_arr[10];
	for (int i = 0;i < 10;i++)
	{
		centre_arr[i] = 0;
	}

	fstream vacc_file;                                 //to read from file
	vacc_file.open("City_data.txt", ios::in);
	while (getline(vacc_file, sub, '\n'))
	{
		if (sub == "")
		{
			continue;
		}

		int vacc_centre = stoi(sub);
		vacc_centre = vacc_centre / 2000;
		centre_arr[i] = vacc_centre;
		i++;
	}
	vacc_file.close();
	return centre_arr;
}
Admin::Admin() :person()
{
	;
}
int Admin::check_login()
{
//	person_setter();
	vaccine obj_vacc;
	int admin_menu_selection;
	bool check = other_roles_files(get_username(), get_password(), get_ID());//check receive true or false in case
   //of true login is successfull or in case of false login is not successfull
	if (check == false)
	{
		cout << "programm terminate beacause login is not successfull" << endl;
		cout << "With this credentials we have no person in our record" << endl;
		return 0;
	}
	if (check == true)
	{
		admin_menu_selection = 1;
		cout << "since you successfully login" << endl;
		while (admin_menu_selection != 0)
		{
			cout << "so,here is the menu" << endl;
			cout << "1-Add vaccine" << endl;
			cout << "2-store in warehouse" << endl;
			cout << "3-Distribute throughtout the country" << endl;
			cout << "To exit please enter 0" << endl;
			cin >> admin_menu_selection;
			while ((admin_menu_selection < 0) || (admin_menu_selection > 3))
			{
				cout << "You put wrong input please again enter input" << endl;
				cout << "so,here is the menu" << endl;
				cout << "1-Add vaccine" << endl;
				cout << "2-store in warehouse" << endl;
				cout << "3-Distribute throughtout the country" << endl;
				cout << "To exit please enter 0" << endl;
				cin >> admin_menu_selection;
			}
			if (admin_menu_selection == 1)
			{
				obj_vacc.add_vaccine();
			}
			else if (admin_menu_selection == 2)
			{
				obj_vacc.store_in_warehouse();
			}
			else if (admin_menu_selection == 3)
			{
				obj_vacc.vaccination_centres();
			}
			else if (admin_menu_selection == 0)
			{
				return 1;
				//menu();
			}
		}
	}
	return 0;
}

// vaccinaton centres



int vaccine::vacc_data_file()           //data of purchased vaccine
{
	fstream vaccine_info;
	vaccine_info.open("V_information.txt");
	if (!vaccine_info)
	{
		cout << "Vaccine information file does not open\n";
		return -4;
	}
	else
	{
		vaccine_info << "TOTAL VACCINES PURCHASED:" <<Number_of_doses << endl;
		vaccine_info << "Total Doses of SINOPHARM:" << total_sinopharm << endl;
		vaccine_info << "Total Doses of PFIZER:" << total_pfizer << endl;
		vaccine_info << "Number of PFIZER vaccine which each warehouse has:" << each_warehose_pfizer <<endl;
		vaccine_info << "Number of SINOPHARM vaccine which each warehouse has:" << each_warehouse_sinopharm << endl;
		vaccine_info << "Expiry date:" << e_obj.date << ":" << e_obj.month << ":" << e_obj.year << endl;

	}
	return 0;
}
int Doctor::check_login()
{
	bool check = other_roles_files(get_username(), get_password(), get_ID());//check receive true or false in case
   //of true login is successfull or in case of false login is not successfull
	if (check == false)
	{
		cout << "programm terminate beacause login is not successfull" << endl;
		cout << "With this credentials we have no person in our record" << endl;
		return 1;
	}
	if (check == true)
	{
		cout << "Sice ypu successfully login" << endl;
		cout << "Enter your duty days: ";
		cin >> this->duty_days;
		return 1;
	}


}
FDO::FDO() :person()
{
	;
}


void Doctor::citizen_file(int x,int y,int z)
{
	//c_obj is used to access all the getter of citizen and write in r_citizen class
	fstream r_citizen;
	r_citizen.open("registered_citizen.txt");
	if (!r_citizen)
	{
		cout << "OOPS! error in openning registered citizen file\n";
	}
	else
	{
		cout << "Registered citizen file open successfully open\n";
		//normal blood pressure 160-180
		//normal oxygen level 90-95
		//normal glucose level 85-95
		//1-blood pressure,2-oxygen level,3-glucose level
			if ((x >= 160) && (x <= 180))
			{
				if ((y >= 90) && (y <= 95))
				{
					if ((z >= 80) && (z <= 95))
					{
						cout << "patient has normal blood pressure, oxygen level, and glucose level" << endl;
						r_citizen << "patient has normal blood pressure, oxygen level, and glucose level" << endl;
						r_citizen << "B.P " << x << " OL " << y << " GL " <<z << endl;
					}
					else
					{
						cout << "Patient histroy does not allow to get vaccinated" << endl;
					}
				}
				else
				{
					cout << "This patient histroy does not allow to get vaccinated" << endl;
				}
			}
			else
			{
				cout << "This patient histroy does not allow to get vaccinated" << endl;
			}

	}
}
void FDO::eligibility(int x, int y, int z)
{
	Doctor d_obj;
	d_obj.citizen_file(x,y,z);
}
void citizen::fun()
{
	FDO f_obj;
	int temp = 2022 - b_year;
	if (temp > 5)
	{
		f_obj.eligibility(BP, OL, GL);
	}
}

void::FDO::assign_counter()
{
	const int counters = 3;
	static int  counter_array[3] = { 2,3,4 };   //aik counter array hai us k rows equal hein number of counters in each vaccination centre                                                         //aur column k index pr busy_space pari hai jo k static hai 
	int index = 0;
	int min = 0;
	int count = 0;
	
	//while (count != -1) {

	min = counter_array[0];
	//cout << "min:  " << min << endl;
	for (int i = 0;i < counters;i++)
	{
		if (min > counter_array[i]) {
			min = counter_array[i];
			index = i;
		}
	}
	counter_array[index] = counter_array[index] + 1;
	cout << "You are assigned with counter#  " << index + 1 << endl;
	//cout << "cin number :";cin >> count;
//}
}


int FDO::login_check()
{
	citizen c_obj;
	int FDO_menu_selection = 0;
	bool check = other_roles_files(get_username(), get_password(), get_ID());               //check receive true or false in case
   //of true login is successfull or in case of false login is not successfull
	if (check == false)
	{
		cout << "OOPS! Programm terminate beacause login is not successfull" << endl;
		cout << "With this credentials we have no person in our record" << endl;
		return 0;
	}
	if (check == true)
	{
		cout << "Since you successfully login" << endl;
		while (FDO_menu_selection != 3)
		{
			cout << "So,here is the menu:" << endl;
			cout << "1-Add counter" << endl;
			cout << "2-Check citizen's eligibility" << endl;
			cout << "3-exit" << endl;
			cin >> FDO_menu_selection;

			if (FDO_menu_selection == 1) {
				assign_counter();            //ye check counter k pass chla jaaye ga counter assign krnay
			}
			if (FDO_menu_selection == 2)
			{
				c_obj.set_citizen();
				c_obj.fun();
			}
		}
		return 1;
	}
	return 1;
}
void citizen::set_citizen()
{
	cout << "Enter name: ";
	cin >> name;
	cout << "Enter email: ";
	cin >> email;
	cout << "Enter CNIC: ";
	cin >> CNIC;
	cout << "Enter blood type: ";
	cin >> blood_type;
	cout << "Enter your birth date: ";
	cin >> b_date;
	cout << "Enter your birth month: ";
	cin >> b_month;
	cout << "Enter your birth year: ";
	cin >> b_year;
	cout << "Enter BP: ";
	cin >> BP;
	cout << "Enter OL: ";
	cin >> OL;
	cout << "Enter GL: ";
	cin >> GL;
}

////////////////////////////////////////////SUPER ADMIN///////////////////////////////////////////////////////
//int superadmin::s_login_check()
//{
//	int s_menu_selection;
//	bool check = other_roles_files(get_username(), get_password(), get_ID());
//	if (check == false)
//	{
//		cout << "OOPS! Programm terminate beacause login is not successfull" << endl;
//		cout << "With this credentials we have no person in our record" << endl;
//		return 0;
//	}
//	else if (check == true)
//	{
//		cout << "Since you successfully login" << endl;
//		cout << "here is menu" << endl;
//		cout << "1-add user" << endl;
//		cin >> s_menu_selection;
//		fstream other_roles;
//		other_roles.open("other_roles.txt", ios::app);
//		if (!other_roles.is_open()) {
//			cout << "OOPS! error in openning other roles file in super admin\n";
//			return 1;
//		}
//		else
//		{
//			cout <<  "other roles file opened successfully in super admin" << endl;
//			other_roles << "almas" << endl;
//			cout << "almas" << endl;
//			return 0;
//		}
//	}
//}


