#pragma once
#include<string>
using namespace std;
#include <fstream>

int menu();
void allignment();
bool other_roles_files(string, string, string);//global function for role menu
class Admin;   //forward declaration of admin class





///////////////////////////PERSON CLASS////////////////////////////

class person
{
protected:
	string username;
	string password;
	string ID;
public:
	person();
	string get_username();
	string get_password();
	string get_ID();
};




////////////////////////ADMIN CLASS////////////////////////////

class Admin :public person
{
public:
	Admin();
	int check_login();

};


//////////////////////////VACCINE CLASS///////////////////////


class vaccine {
public:
	double r_Number_of_doses;
	double r_total_sinopharm;
	double r_total_pfizer;
	    // vaccine_type V_type;
	    long double Price_spent_on_vaccines;
		 int Batch_ID;
public:
	double getter_Number_of_doses();
	int add_vaccine( );
	 int vacc_data_file( );
	void store_in_warehouse();
	int *vaccination_centres();
	friend int Admin_menu();
};

struct expiry_date
{
	int date;
	int month;
	int year;
};
class Doctor :public person
{
private:
	string duty_days;
public:
	int check_login();
	void citizen_file(int x,int y,int z);
};
class citizen
{
private:
	string name;
	string email;
	string CNIC;
	char blood_type;
	int b_date;
	int b_month;
	int b_year;
	int BP;
	int OL;
	int GL;
public:
	void set_citizen();
	void fun();
};
class FDO :public person
{
public:
	FDO();
	int login_check();
	void assign_counter();
	void eligibility(int x,int y,int z);
};
class superadmin:public person
{
public:
	int s_login_check();
};
