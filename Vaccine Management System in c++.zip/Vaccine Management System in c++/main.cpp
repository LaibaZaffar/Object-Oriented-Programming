#include<iostream>
#include<string>
#include"class.h"
using namespace std;

int main()
{
	allignment();
	int x = menu();
	while (x != 0)
	{
		/*if (x == 1)
		{
			superadmin s_obj;
			s_obj.s_login_check();
		}*/
		
		if (x == 2)
		{
			Admin a_obj;
			a_obj.check_login();
			x = menu();
		}
		else if (x == 3)
		{
			Doctor d_obj;
			d_obj.check_login();
			x = menu();
		}
		else if (x == 4)
		{
			FDO f_obj;
			f_obj.login_check();
			x = menu();
		}
		else if (x == 6)
		{
			citizen c_obj;
			c_obj.set_citizen();
			x = menu();
		}
	}
	if (x == 0)
	{
		cout << "you exit the program" << endl;
		return 0;
	}
	system("pause");

}