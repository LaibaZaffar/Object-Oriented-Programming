#include<iostream>
using namespace std;
class hotDogs
{
private:

	int id_number;
	int sold_hotDogs;
	int hd;

public:
	static int total_sold_hotDogs;

	hotDogs(int x, int y)  //constructor to initialize values
	{
		id_number = x;
		sold_hotDogs = y;
	}
	void  justSold(int num, int id)    // to increment for  stole
	{
		if (num == 2)
		{
			cout << "Enter the number of Hot Dogs you want to purchase: ";
			cin >> hd;
			sold_hotDogs += hd;
			totalSold(sold_hotDogs);
		}
		else if (num == 1)
		{
			cout << "Sale from id  " << id_number << "is:  " << sold_hotDogs << endl;
			sold_hotDogs = 0;
			cout << "Enter the new Id-number: ";
			cin >> id;
			id_number = id;
			cout << "Enter the number of Hot Dogs you want to purchase: ";
			cin >> hd;
			sold_hotDogs += hd;
			totalSold(sold_hotDogs);

		}

		else if (num == 3)
		{
			cout << "Sale from id  " << id_number << " is:   " << sold_hotDogs << endl;
			cout << "Total Hot dogs sold are:  " << total_sold_hotDogs<<endl;
		}

	}

	void  totalSold(int x)       // to increment in static
	{
		total_sold_hotDogs+=x;
	}
	
};
int hotDogs::total_sold_hotDogs = 0;
int main()
{
	bool flag = true;
	int id = 0, shd = 0, ans = 0;
	cout << "Enter the ID number for stall:  ";
	cin >> id;
	cout << "Enter the number of sold hot dogs:  ";
	cin >> shd;
	hotDogs obj(id, shd);
	while(! flag==false)
	{
		cout << "ENTER '1' for change the id_number: \n";
		cout << "Enter '2' for continue by previous ID: \n";
		cout << "Enter '3' to exit: \n";
		cin >> ans;
		obj.justSold(ans, id);
		if (ans == 3)
		{
			flag = false;
		}

	}







}

