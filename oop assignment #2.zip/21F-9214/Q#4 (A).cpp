# include <iostream>
using namespace std;
void func()
{
	cout<<"Hello ia am a function"<<endl;
}
void test(void (*ptr)())    //passing the adress of a function as an argument to another function
{
	(*ptr)();
}
int main()
{
	void (*pointer)()=&func;            //storing the address of a function
	test(pointer);                           //passing the address of a pointer
	system("pause");
	return 0;
}

