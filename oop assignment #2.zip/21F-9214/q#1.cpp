#include<iostream>
#include<string>
using namespace std;

class bankAccount
{
	string name;
	int acc_number;
	char acc_type;
	float balance;
	
public:
	static string bank_name;
	static int branch_code;
	static string city;

	bankAccount (string name, int acn, char act, float ball)   //constructor
	{
		this->name = name;
		acc_number = acn;
		acc_type = act;
		balance = ball;
	}

 
	void setDeposite_amount(float amount)   //deposite function
	{
		balance += amount;
	}
	void with_draw(float w_amount)   //withdarw function 
	{
		if (w_amount < balance)
		{
			balance -= w_amount;
		}
		else {
			cout << "OOPS! You do not have enough amount\n";
		}

	}
	void display() //display function
	{
		cout << "\n\n\             DETAILS\n";
		cout << "Name of Depositer is  " << name << endl;
		cout << "Bnak name is  " << bank_name << endl;
		cout << "City name is  " << city << endl;
		cout << "Account Balance is  " << balance << endl;

	}

};

string bankAccount::bank_name = "";
string bankAccount::city = "";
int  bankAccount::branch_code = 0;


int main()
{
	string n;int acn;char act;float bal;float dep, wdraw;
	
	cout << "Enter the name of depositer:  ";
	cin >> n;
	cout << "Enter the account number of depositer:  ";
	cin >> acn;
	cout << "Enter the account type of depositer.\n 'c' for current \n 's' for saving :   ";
	cin >> act;
	cout << "Enter the current balance of depositer:  ";
	cin >> bal;
	bankAccount obj(n, acn, act, bal);
	cout << "Enter the bank name :  ";
	cin >> bankAccount::bank_name;
	cout << "Enter the branch code of bank ";
	cin >> bankAccount::branch_code;
	cout << "Enter the bank city:  ";
	cin >> bankAccount::city;
	cout << "Enter the deposite amount if any:  ";
	cin >> dep;
	obj.setDeposite_amount(dep);
	cout << "Enter the amount to be withdraw if any:  ";
	cin >> wdraw;
	obj.with_draw(wdraw);
	obj.display();

}

