# include <iostream>
using namespace std;
int add(int x,int y)
{
	return x+y;
}
int sub(int x,int y)
{
	return x-y;
}
int mult(int x,int y)
{
	return x*y;
}
int divide(int x,int y)
{
	return x/y;
}
int main()
{
	cout<<"Press 1 for sum"<<endl;
	cout<<"Press 2 for subtraction"<<endl;
	cout<<"Press 3 for multiplication"<<endl;
	cout<<"Press 4 for division"<<endl;
	int num1,num2,z;
    int (*ptr[4])(int,int);
	cin>>z;
	cout<<"Enter first number: ";
	cin>>num1;
	cout<<"Enter second number: ";
	cin>>num2;
	ptr[0]= &add;
	ptr[1]=&sub;
	ptr[2]=&mult;
	ptr[3]=&divide;
    if(z==1)
	{
        cout<<ptr[0](num1,num2)<<endl;
    }
    if(z==2)
    {
	    cout<<ptr[1](num1,num2)<<endl;
    }
    if(z==3)
	{
        cout<<ptr[2](num1,num2)<<endl;
    }
    if(z==4)
    {
	    cout<<ptr[3](num1,num2)<<endl;
    }
	system("pause");
	return 0;
}

