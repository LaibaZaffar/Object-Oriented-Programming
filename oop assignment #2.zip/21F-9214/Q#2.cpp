#include<iostream>
using namespace std;
class extra
{
	int max;
	float yes;
	double  bye;
	//constructor
public:
	extra(int max,float yes,double bye)
	{
		this->max = max;
		this->yes = yes;
		this->bye = bye;
	}
	void dispaly() {
		cout << "\nAfter using 'this' operator\n";
		cout << "max=  " << max << endl;
		cout << "yes=  " << yes << endl;
       	cout << "bye=  " << bye << endl;
		cout << "I am happy now :) \n";
	 }
};
int main()
{
	extra obj1(2, 3.4, 56.54);
	extra obj2(3,4.5,45.76);
	cout << "Output for obj1 \n";
	obj1.dispaly();
	cout << "\nOutput for obj2 \n";
	obj2.dispaly();
}
